---
description: "Run the full guided Mac AI setup wizard - installs tools, configures providers, and verifies the stack"
---

# Full Setup Wizard

Guide through the complete Mac AI development environment setup.

## Steps

1. Check prerequisites (Node.js 18+, Homebrew, Apple Silicon)
2. Install inference stack: `brew install ollama llama.cpp mostlygeek/llama-swap/llama-swap && brew install --cask lm-studio && brew install gollama`
3. Create shared model folder: `mkdir -p ~/AI/models/{lmstudio,ollama,mlx,gguf,shared} && ln -sf ~/AI/models/lmstudio ~/.lmstudio/models`
4. Configure Gollama and Ollama environment variables
5. Start Ollama: `ollama serve`
6. Install claude-code-router: `npm install -g @musistudio/claude-code-router`
7. Configure CCR at `~/.claude-code-router/config.json`
8. Start CCR: `ccr start`
9. Create cc-mirror variants for desired providers
10. Run health check to verify everything works

Ask user which providers they want (Mirror, Z.ai, MiniMax, Kimi, OpenRouter, local CCR) and guide through API key setup for each.

When done, run the health check script at `scripts/check-stack.sh` to verify.

$ARGUMENTS contains optional flags like "local-only" (skip cloud providers) or "full" (all providers).
