# Provider Comparison Matrix (February 2026)

## Cloud Providers

| Provider | Models | SWE-Bench | Context | Input $/M | Output $/M | Tool-Calling | Team Mode |
|----------|--------|-----------|---------|-----------|------------|-------------|-----------|
| Anthropic (Mirror) | Opus 4.6, Sonnet 4.5, Haiku 4.5 | 80.8% | 1M | $3-5 | $15-25 | Excellent | Default |
| Z.ai | GLM-5, GLM-4.7 | 73.8% | 200K | ~$3/mo flat | (120-600 prompts) | Good | Manual |
| MiniMax | M2.5, M2.1 | 80.2% | 1M | $0.27 | $0.95 | Excellent | Manual |
| Kimi | K2.5 | 76.8% | 256K | $0.60 | $3.00 | Good | Manual |
| OpenRouter | 100+ models | Varies | Varies | Varies | Varies | Varies | Manual |
| Gemini | 3 Pro, 2.0 Flash | 74-76% | 2M | $0.075 | $0.30 | Good | N/A |

## Local Models (Free)

| Model | Active Params | SWE-Bench | Context | RAM Needed | Tool-Calling |
|-------|--------------|-----------|---------|-----------|-------------|
| GLM-4.7-Flash | 30B | 73.8% | 128K | 38GB (Q8_0) | Good |
| Qwen3-Coder-30B | 3B (of 30B) | 70.6% | 128K | 20GB | Good |
| Qwen3-Coder-Next | 3B (of 80B) | 70.6% | 128K | 52GB | Good |
| MiniMax M2.5 | 10B (of 230B) | 80.2% | 1M | 76GB (5bit) | Excellent |
| Devstral Small 2 | 24B | 72.2% | 128K | 24GB (Q8_0) | Moderate |
| RANO agents (x21) | 0.6B | Domain-specific | 4K | 484MB each | Good |

## Subscription Plans

| Plan | Price | Provider | Best For |
|------|-------|----------|----------|
| Claude Max | $100/mo | Anthropic | Enterprise reasoning |
| Claude Pro | $17/mo | Anthropic | Individual devs |
| MiniMax Starter | $100/yr | MiniMax | Budget agents |
| Z.ai Lite | $3/mo | Z.ai | Experimentation |
| OpenRouter PAYG | Pay-per-use | Multi | Flexibility |
| Local | $0 | Self-hosted | Privacy, cost |
